const layout = ({children}) => {
  return (
    <div className="">            
        {children}
        </div>
  )
}

export default layout