import Loader from '@/components/Loader';

const loading = () => <Loader />;

export default loading;
